/**
 * Created by Nguyen on 20/10/2015.
 */
jQuery(function(jQuery) {
    jQuery(document).ready(function(){
        jQuery('#insert-my-media').click(open_media_window);
    });

    function open_media_window() {
    }
});